# 🌐 VIETLOTT AUTO FETCHER - Tự động lấy kết quả

## 🎯 TỔNG QUAN

Hệ thống có **3 CÁCH** để lấy kết quả Bingo 18:

### 1️⃣ **Auto từ Vietlott.vn** ⭐ RECOMMENDED
- ✅ Hoàn toàn tự động
- ✅ Không cần nhập tay
- ✅ Check mỗi 3 phút
- ✅ Tự động lưu database + gửi Telegram

### 2️⃣ **Web Admin Interface**
- ✅ Nhập thủ công qua giao diện web
- ✅ Click chọn số, dễ dàng
- ✅ http://localhost:5000/admin

### 3️⃣ **Kết hợp cả 2**
- Auto fetcher chạy nền
- Backup bằng Admin nếu cần

---

## 🚀 CÁCH 1: AUTO TỪ VIETLOTT.VN

### **Bước 1: Chạy Main System**
```bash
python main.py
```
Hệ thống sẽ:
- Chạy Dashboard (http://localhost:5000)
- Dự đoán tự động mỗi 6 phút
- Gửi Telegram

### **Bước 2: Chạy Vietlott Fetcher (Tab/Terminal riêng)**
```bash
python run_vietlott_fetcher.py
```

Fetcher sẽ:
- Check Vietlott.vn mỗi 3 phút
- Tự động lấy kết quả mới
- Lưu vào database
- Gửi Telegram
- Tự động check dự đoán

---

## 📊 OUTPUT MẪU

```
============================================================
🌐 VIETLOTT AUTO FETCHER
============================================================
Tự động lấy kết quả từ https://vietlott.vn
Check mỗi 3 phút (180 giây)
============================================================

🔌 Testing connection...
✅ Connected to Vietlott.vn

📊 Last draw in database: #12345

🚀 Auto fetcher started!
Press Ctrl+C to stop

[14:30:25] Checking Vietlott...
  ✅ New: #12346 - [0, 3, 5]
  💾 Saved (ID: 456)
  🎯 2/3 - WIN
  ⏰ Next check in 180s...

[14:33:25] Checking Vietlott...
  Already processed #12346
  ⏰ Next check in 180s...
```

---

## 🎮 WORKFLOW HOÀN CHỈNH

```
[Terminal 1: Main System]
├── Dashboard (http://localhost:5000)
├── Scheduler (dự đoán mỗi 6 phút)
└── Telegram notifications

[Terminal 2: Vietlott Fetcher]
├── Check Vietlott.vn mỗi 3 phút
├── Lấy kết quả mới
├── Lưu database
├── Update predictions
└── Gửi Telegram

[Telegram Bot]
├── Nhận dự đoán (mỗi 6 phút)
├── Nhận kết quả (ngay khi có)
└── Nhận thống kê
```

---

## 💻 LỆNH ĐẦY ĐỦ

### **Windows:**
```cmd
# Terminal 1 - Main System
python main.py

# Terminal 2 - Vietlott Fetcher
python run_vietlott_fetcher.py
```

### **Linux/Mac:**
```bash
# Terminal 1
python3 main.py

# Terminal 2
python3 run_vietlott_fetcher.py
```

### **VPS (Chạy cả 2 dưới dạng service):**
```bash
# Install service sẽ tự động setup
sudo bash install_service.sh

# Fetcher sẽ được tích hợp vào service
```

---

## ⚙️ CẤU HÌNH

### **Thay đổi interval check:**

Sửa trong `run_vietlott_fetcher.py`:
```python
interval = 180  # 3 phút (mặc định)
# Có thể đổi thành:
interval = 120  # 2 phút
interval = 300  # 5 phút
```

### **Test thử fetcher:**

```bash
python vietlott_fetcher.py
```

Output:
```
Testing Vietlott connection...

✅ Connected to Vietlott.vn

Fetching latest result...

✅ Success!
  Draw: #12346
  Numbers: [0, 3, 5]
  Time: 2026-02-01 14:30:00
```

---

## 🔧 TROUBLESHOOTING

### **❌ Lỗi: Cannot connect to Vietlott.vn**

**Nguyên nhân:** Mạng chặn hoặc Vietlott thay đổi giao diện

**Giải pháp:**
1. Kiểm tra internet
2. Thử truy cập https://vietlott.vn bằng trình duyệt
3. Nếu web layout thay đổi, cần update parsing logic

### **❌ Lỗi: Could not fetch result**

**Nguyên nhân:** HTML structure của Vietlott thay đổi

**Giải pháp:**
1. Vào https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/bingo-18
2. View source (Ctrl+U)
3. Tìm HTML structure chứa kết quả
4. Update parsing logic trong `vietlott_fetcher.py`

### **❌ Lỗi: Module 'bs4' not found**

```bash
pip install beautifulsoup4 lxml
```

---

## 📱 TELEGRAM NOTIFICATIONS

### **Khi fetcher khởi động:**
```
🌐 Vietlott Auto Fetcher đã khởi động!

Tự động check kết quả mỗi 3 phút
```

### **Khi có kết quả mới:**
```
🎲 Kết quả Bingo 18 mới

Kỳ #12346
Số ra: 0 - 3 - 5
Thời gian: 14:30 - 01/02/2026
```

### **Khi dự đoán trúng:**
```
✅ KẾT QUẢ BINGO 18

📊 Kỳ: #12346
⏰ Thời gian: 14:30:00 - 01/02/2026

🎲 Số ra: 0 - 3 - 5
🎯 Số đã dự đoán: 0 - 3 - 6

🤖 Model: hybrid_model
🎯 Trùng: 2/3 số
📊 Kết quả: THẮNG
```

---

## 🎯 SỬ DỤNG TRONG THỰC TẾ

### **Scenario 1: Hoàn toàn tự động**
```bash
# Chạy 1 lần, để máy chạy 24/7
python main.py &
python run_vietlott_fetcher.py &

# Hoặc trên VPS
sudo bash install_service.sh
```

### **Scenario 2: Có backup thủ công**
```bash
# Terminal 1: Main + Fetcher
python main.py

# Terminal 2: Fetcher
python run_vietlott_fetcher.py

# Nếu fetcher miss kỳ nào:
# Mở http://localhost:5000/admin → Nhập thủ công
```

### **Scenario 3: Chỉ dùng Admin**
```bash
# Chỉ chạy main
python main.py

# Nhập kết quả qua web interface
# http://localhost:5000/admin
```

---

## 📊 MONITORING

### **Xem logs Fetcher:**
```bash
# Fetcher sẽ in ra console
# Mỗi 3 phút sẽ có dòng log

[14:30:25] Checking Vietlott...
```

### **Xem logs Main System:**
```bash
tail -f logs/bingo18.log
```

### **Check database:**
```bash
sqlite3 data/bingo18.db "SELECT * FROM draw_history ORDER BY draw_number DESC LIMIT 10;"
```

---

## ⚡ QUICK START

```bash
# 1. Giải nén
unzip bingo18_predictor.zip
cd bingo18_predictor

# 2. Cài packages
pip install -r requirements.txt

# 3. Chạy Main System (Terminal 1)
python main.py

# 4. Chạy Vietlott Fetcher (Terminal 2)
python run_vietlott_fetcher.py

# 5. Mở Dashboard
# http://localhost:5000

# 6. Kiểm tra Telegram
# Sẽ nhận thông báo tự động
```

---

## 🎁 BONUS FEATURES

### **Test fetch ngay:**
```bash
python -c "from vietlott_fetcher import VietlottFetcher; f = VietlottFetcher(); print(f.fetch_latest_bingo18_result())"
```

### **Fetch 1 lần rồi thoát:**
```bash
python -c "from vietlott_fetcher import VietlottAutoFetcher; from database import DatabaseManager; from telegram_bot import TelegramBot; f = VietlottAutoFetcher(DatabaseManager(), TelegramBot()); f.fetch_and_save()"
```

---

## 📝 NOTES QUAN TRỌNG

1. **Vietlott có thể thay đổi HTML structure** → Cần update parsing
2. **Recommend chạy cả Main + Fetcher** → Đầy đủ nhất
3. **Fetcher check mỗi 3 phút** → Không miss kỳ nào
4. **Admin Interface là backup** → Phòng khi fetcher fail

---

## 🆘 HỖ TRỢ

Nếu fetcher không hoạt động:

1. **Check connection:**
   ```bash
   python vietlott_fetcher.py
   ```

2. **View HTML structure:**
   - Vào https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/bingo-18
   - Ctrl+U (view source)
   - Tìm kết quả Bingo 18
   - Copy HTML structure
   - Update parsing trong `vietlott_fetcher.py`

3. **Dùng Admin Interface:**
   - http://localhost:5000/admin
   - Nhập thủ công

---

**🎲 ENJOY AUTO FETCHING!**

_Vietlott Auto Fetcher v1.0 - Hoàn toàn tự động lấy kết quả_
